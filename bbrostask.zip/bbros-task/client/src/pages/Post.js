import React, { useEffect, useState, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { AuthContext } from "../helpers/AuthContext";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import Grid from "@mui/material/Grid";
import Card from "@mui/material/Card";
import CardActionArea from "@mui/material/CardActionArea";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import CardActions from "@mui/material/CardActions";
import Button from "@mui/material/Button";
import { TextField } from "@mui/material";
import Link from "@mui/material/Link";
import CssBaseline from "@mui/material/CssBaseline";
import Box from "@mui/material/Box";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { lightBlue } from "@mui/material/colors";

function Copyright() {
  return (
    <Typography variant="body2" color="text.secondary" align="center">
      {"Copyright © "}
      <Link color="inherit" href="https://www.bbros.eu/">
        BBros L.L.C
      </Link>{" "}
      {new Date().getFullYear()}
      {"."}
    </Typography>
  );
}

const theme = createTheme();

function Post() {
  let { id } = useParams();
  const [postObject, setPostObject] = useState({});
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState("");
  const { authState } = useContext(AuthContext);

  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem("accessToken") || authState.status) return;

    navigate("/login");
  }, [authState.status]);

  useEffect(() => {
    axios.get(`http://localhost:3001/posts/byId/${id}`).then((response) => {
      setPostObject(response.data);
    });

    axios.get(`http://localhost:3001/comments/${id}`).then((response) => {
      setComments(response.data);
    });
  }, []);

  const addComment = () => {
    axios
      .post(
        `http://localhost:3001/comments`,
        {
          commentBody: newComment,
          PostId: id,
        },
        {
          headers: {
            accessToken: localStorage.getItem("accessToken"),
          },
        }
      )
      .then((response) => {
        if (response.data.error) {
          console.log(response.data.error);
        } else {
          const commentToAdd = {
            commentBody: newComment,
            username: response.data.username,
          };
          setComments([...comments, commentToAdd]);
          setNewComment("");
        }
      });
  };

  const deleteComment = (id) => {
    axios
      .delete(`http://localhost:3001/comments/${id}`, {
        headers: { accessToken: localStorage.getItem("accessToken") },
      })
      .then(() => {
        setComments(
          comments.filter((val) => {
            return val.id !== id;
          })
        );
      });
  };
  const deletePost = (id) => {
    axios
      .delete(`http://localhost:3001/posts/${id}`, {
        headers: { accessToken: localStorage.getItem("accessToken") },
      })
      .then(() => {
        navigate("/");
      });
  };

  const editPost = (option) => {
    if (option === "title") {
      let newTitle = prompt("Enter New Title:");
      if (!newTitle) {
        return;
      }
      axios.put(
        "http://localhost:3001/posts/title",
        {
          newTitle: newTitle,
          id: id,
        },
        {
          headers: { accessToken: localStorage.getItem("accessToken") },
        }
      );

      setPostObject({ ...postObject, title: newTitle });
    } else {
      let newPostText = prompt("Enter New Text:");
      if (!newPostText) {
        return;
      }
      axios.put(
        "http://localhost:3001/posts/postText",
        {
          newText: newPostText,
          id: id,
        },
        {
          headers: { accessToken: localStorage.getItem("accessToken") },
        }
      );

      setPostObject({ ...postObject, postText: newPostText });
    }
  };
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />

      <main>
        {/* Hero unit */}
        <Box
          sx={{
            bgcolor: "background.paper",
            pt: 2,
            pb: 4,
          }}
        >
          <Container maxWidth="sm">
            <Typography
              component="h1"
              variant="h2"
              align="center"
              color="text.primary"
              gutterBottom
            ></Typography>
          </Container>
        </Box>

        <Container maxWidth="sm">
          <Grid container spacing={4}>
            <Grid item xs={12} md={12}>
              <CardActionArea component="a" href="#">
                <Card
                  sx={{
                    display: "flex",
                    height: "100%",
                    display: "flex",
                    flexDirection: "column",
                  }}
                >
                  <CardMedia
                    component="img"
                    sx={
                      {
                        // 16: 9,
                      }
                    }
                    image="https://source.unsplash.com/random"
                    alt="random"
                  />
                  {/* <CardContent sx={{ flex: 1}} > */}
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Typography gutterBottom variant="h5" component="h2">
                      <div
                        className="title"
                        onClick={() => {
                          if (authState.username === postObject.username) {
                            editPost("title");
                          }
                        }}
                      >
                        {" "}
                        {postObject.title}{" "}
                      </div>
                    </Typography>
                    <div
                      className="body"
                      onClick={() => {
                        if (authState.username === postObject.username) {
                          editPost("body");
                        }
                      }}
                    >
                      {" "}
                      {postObject.postText}
                    </div>

                    <div className="username">{postObject.username}</div>

                    <CardActions sx={{ background: lightBlue }}>
                      {authState.username === postObject.username && (
                        <Button
                          className="username"
                          onClick={() => {
                            deletePost(postObject.id);
                          }}
                          size="medium"
                        >
                          Delete
                        </Button>
                      )}

                      {/* <Button
                        className="editi buttons"
                        size="medium"
                      >
                        Edit
                      </Button> */}
                    </CardActions>
                  </CardContent>
                </Card>
              </CardActionArea>
            </Grid>
          </Grid>
          <CardContent sx={{ flex: 1 }}>
            <div className="rightSide">
              <div className="addCommentContainer">
                <TextField
                  margin="normal"
                  type="text"
                  fullWidth
                  placeholder="Write down a comment about this post"
                  value={newComment}
                  onChange={(event) => {
                    setNewComment(event.target.value);
                  }}
                />
                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  onClick={addComment}
                >
                  Add Comment
                </Button>
              </div>
              <h3>Comments about this post</h3>

              <div className="listOfComments">
                {comments.map((comment, key) => {
                  return (
                    <div key={key} className="comment">
                      <Card sx={{ display: "flex", mb: 4 }}>
                        <CardContent sx={{ flex: 1 }}>
                          <p>{comment.commentBody}</p>
                          <hr />

                          <div className="username">{comment.username}</div>
                          <div className="buttonDelete">
                            {authState.username === comment.username && (
                              <DeleteForeverIcon
                                onClick={() => {
                                  deleteComment(comment.id);
                                }}
                              />
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Container>
      </main>
      <Copyright sx={{ mt: 5 }} />
    </ThemeProvider>
  );
}

export default Post;
