import React, { useContext, useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../helpers/AuthContext";
import FavoriteBorderIcon from "@mui/icons-material/FavoriteBorder";
import Button from "@mui/material/Button";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import CssBaseline from "@mui/material/CssBaseline";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import Link from "@mui/material/Link";
import { createTheme, ThemeProvider } from "@mui/material/styles";

function Copyright() {
  return (
    <Typography variant="body2" color="text.secondary" align="center">
      {"Copyright © "}
      <Link color="inherit" href="https://www.bbros.eu/">
        BBros L.L.C
      </Link>{" "}
      {new Date().getFullYear()}
      {"."}
    </Typography>
  );
}

// const cards = [1, 2, 3, 4, 5, 6, 7, 8, 9];

const theme = createTheme();

function Home() {
  const [listOfPosts, setListOfPosts] = useState([]);
  const [likedPosts, setLikedPosts] = useState([]);
  const { authState } = useContext(AuthContext);
  const navigate = useNavigate();

  const likeAPost = (postId) => {
    axios
      .post(
        "http://localhost:3001/likes",
        { PostId: postId },
        { headers: { accessToken: localStorage.getItem("accessToken") } }
      )
      .then((response) => {
        setListOfPosts(
          listOfPosts.map((post) => {
            if (post.id === postId) {
              if (response.data.liked) {
                return { ...post, Likes: [...post.Likes, 0] };
              } else {
                const likesArray = post.Likes;
                likesArray.pop();
                return { ...post, Likes: likesArray };
              }
            } else {
              return post;
            }
          })
        );

        if (likedPosts.includes(postId)) {
          console.log("true");
          setLikedPosts(
            likedPosts.filter((id) => {
              return id !== postId;
            })
          );
        } else {
          console.log(response.data);
          setLikedPosts([...likedPosts, postId]);
        }
      });
  };

  const checkLikeColor = (id) => {
    return likedPosts.find((post) => post.PostId == id);
  };

  useEffect(() => {
    if (localStorage.getItem("accessToken") || authState.status) return;

    navigate("/login");
  }, [authState.status]);

  useEffect(() => {
    if (!localStorage.getItem("accessToken")) {
      navigate("/login");
    } else {
      axios
        .get("http://localhost:3001/posts", {
          headers: { accessToken: localStorage.getItem("accessToken") },
        })
        .then((response) => {
          console.log(response.data);
          setListOfPosts(response.data.listOfPosts);
          setLikedPosts(response.data.likedPosts.map((post) => post));
        });
    }
  }, []);

  return (
    <div>
      <ThemeProvider theme={theme}>
        <CssBaseline />

        <main>
          {/* Hero unit */}
          <Box
            sx={{
              bgcolor: "background.paper",
              pt: 2,
              pb: 4,
            }}
          >
            <Container maxWidth="sm">
              <Typography
                component="h1"
                variant="h2"
                align="center"
                color="text.primary"
                gutterBottom
              >
                Posts
              </Typography>
            </Container>
          </Box>
          {listOfPosts.map((value, key) => {
            return (
              <div>
                <Container sx={{ py: 8 }} maxWidth="md">
                  {/* End hero unit */}
                  <Grid container spacing={4}>
                    {/* {cards.map((card) => ( */}
                    <Grid item key={key} xs={12} sm={12} md={12}>
                      <Card
                        sx={{
                          height: "100%",
                          display: "flex",
                          flexDirection: "column",
                        }}
                      >
                        <CardMedia
                          component="img"
                          sx={
                            {
                              // 16: 9,
                            }
                          }
                          image="https://source.unsplash.com/random"
                          alt="random"
                        />
                        <CardContent sx={{ flexGrow: 1 }}>
                          <Typography gutterBottom variant="h5" component="h2">
                            {value.title}
                          </Typography>
                          <Typography>{value.postText}</Typography>
                        </CardContent>
                        <CardActions>
                          <Button
                            className="username"
                            onClick={() => {
                              navigate(`/post/${value.id}`);
                            }}
                            fullWidth
                          >
                            View
                          </Button>
                        </CardActions>
                        <CardActions>
                          <div className="username">
                            {/* <Link to={`/profile/${value.UserId}`}></Link> */}
                            {value.username}
                          </div>
                          <div className="buttons">
                            <FavoriteBorderIcon
                              onClick={() => {
                                likeAPost(value.id);
                              }}
                              className={
                                checkLikeColor(value.id)
                                  ? "likeBttn"
                                  : "unlikeBttn"
                              }
                            />
                            <label> {value.Likes.length}</label>
                          </div>
                        </CardActions>
                      </Card>
                    </Grid>
                    {/*  ))} */}
                  </Grid>
                </Container>
              </div>
            );
          })}
        </main>
        <Copyright sx={{ mt: 5 }} />
      </ThemeProvider>
    </div>
  );
}
export default Home;
