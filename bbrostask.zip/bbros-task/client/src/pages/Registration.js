import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import Link from "@mui/material/Link";
import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import Typography from "@mui/material/Typography";
import { createTheme, ThemeProvider } from "@mui/material/styles";

function Copyright(props) {
  return (
    <Typography
      variant="body2"
      color="text.secondary"
      align="center"
      {...props}
    >
      {"Copyright © "}
      <Link color="inherit" href="https://www.bbros.eu/">
        BBros L.L.C
      </Link>{" "}
      {new Date().getFullYear()}
      {"."}
    </Typography>
  );
}

const theme = createTheme();

function Registration() {
  const navigate = useNavigate();

  const initialValues = {
    firstname: "",
    lastname: "",
    bday: "",
    username: "",
    password: "",
  };

  const validationSchema = Yup.object().shape({
    firstname: Yup.string().required(),
    lastname: Yup.string().required(),
    bday: Yup.date().required(),
    username: Yup.string().min(3).max(15).required(),
    password: Yup.string().min(4).max(20).required(),
  });

  const onSubmit = (data) => {
    axios.post("http://localhost:3001/auth", data).then(() => {
      console.log("sukeses", data);
      navigate("/login");
    });
  };

  return (
    <ThemeProvider theme={theme}>
      <Grid container component="main" sx={{ height: "100vh" }}>
        <CssBaseline />
        <Grid
          item
          xs={false}
          sm={4}
          md={7}
          sx={{
            backgroundImage: "url(https://source.unsplash.com/random)",
            backgroundRepeat: "no-repeat",
            backgroundColor: (t) =>
              t.palette.mode === "light"
                ? t.palette.grey[50]
                : t.palette.grey[900],
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <Grid item xs={12} sm={8} md={5} component={Paper} elevation={6} square>
          <Box
            sx={{
              my: 8,
              mx: 4,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
            }}
          >
            <Avatar sx={{ m: 1, bgcolor: "secondary.main" }}>
              <LockOutlinedIcon />
            </Avatar>
            <Typography component="h1" variant="h5">
              Sign Up
            </Typography>
            {/* EXTRA  */}
            <Formik
              initialValues={initialValues}
              onSubmit={onSubmit}
              validationSchema={validationSchema}
            >
              <Form>
                <Box sx={{ mt: 1 }}>
                  <label>FirstName: </label>
                  <ErrorMessage name="firstname" component="span" />
                  <Field
                    variant="standard"
                    margin="normal"
                    required
                    className="inputi"
                    name="firstname"
                    label="First Name"
                    autoComplete="off"
                    autoFocus
                  />
                  <label>LastName: </label>
                  <ErrorMessage name="lastname" component="span" />
                  <Field
                    variant="standard"
                    margin="normal"
                    required
                    className="inputi"
                    name="lastname"
                    label="Last Name"
                    type="lastname"
                    autoComplete="off"
                  />
                  <label>Username</label>
                  <ErrorMessage name="username" component="span" />
                  <Field
                    variant="standard"
                    margin="normal"
                    required
                    className="inputi"
                    name="username"
                    label="Username"
                    type="username"
                    autoComplete="off"
                  />
                  <label>Password: </label>
                  <ErrorMessage name="password" component="span" />
                  <Field
                    variant="standard"
                    margin="normal"
                    required
                    className="inputi"
                    name="password"
                    label="Password"
                    type="password"
                    autoComplete="off"
                  />
                  <label>Birthday: </label>
                  <ErrorMessage name="bday" component="span" />
                  <Field
                    variant="standard"
                    margin="normal"
                    required
                    className="inputi"
                    name="bday"
                    label="Birthday"
                    type="date"
                    autoComplete="off"
                  />

                  <Button
                    type="submit"
                    fullWidth
                    variant="contained"
                    sx={{ mt: 3, mb: 2 }}
                  >
                    Sign Up
                  </Button>

                  <Grid container>
                    <Grid item xs>
                      {/* <Link href="#" variant="body2">
                        Forgot password?
                      </Link> */}
                    </Grid>
                    <Grid item>
                      <Link href="./login" variant="body2">
                        {"You already registered? Sign In"}
                      </Link>
                    </Grid>
                  </Grid>
                  <Copyright sx={{ mt: 5 }} />
                </Box>
              </Form>
            </Formik>
          </Box>
        </Grid>
      </Grid>
    </ThemeProvider>
  );
}
export default Registration;
