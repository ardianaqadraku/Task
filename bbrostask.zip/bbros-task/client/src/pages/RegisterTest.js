import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import axios from "axios";

function Registration() {
  const initialValues = {
    firstname: "",
    lastname: "",
    bday: "",
    username: "",
    password: "",
  };

  const validationSchema = Yup.object().shape({
    firstname: Yup.string().required(),
    lastname: Yup.string().required(),
    bday: Yup.date().required(),
    username: Yup.string().min(3).max(15).required(),
    password: Yup.string().min(4).max(20).required(),
  });

  const onSubmit = (data) => {
    axios.post("http://localhost:3001/auth", data).then(() => {
      console.log("sukeses", data);
    });
  };

  return (
    <div>
      <Formik
        initialValues={initialValues}
        onSubmit={onSubmit}
        validationSchema={validationSchema}
      >
        <Form className="formContainer">
          <label>FirstName: </label>
          <ErrorMessage name="firstname" component="span" />
          <Field
            id="inputCreatePost"
            name="firstname"
            placeholder="Your first name"
          />
          <label>LastName: </label>
          <ErrorMessage name="lastname" component="span" />
          <Field
            id="inputCreatePost"
            name="lastname"
            placeholder="Your lastname"
          />
          <label>
            Username <i>pick an unique username</i>
          </label>
          <ErrorMessage name="username" component="span" />
          <Field
            id="inputCreatePost"
            name="username"
            placeholder="a username "
          />

          <label>Password: </label>
          <ErrorMessage name="password" component="span" />
          <Field
            type="password"
            id="inputCreatePost"
            name="password"
            placeholder="Your Password..."
          />
          <label>Data lindjes: </label>
          <ErrorMessage name="bday" component="span" />
          <Field type="date" id="inputCreatePost" name="bday" placeholder="" />
          <button type="submit"> Register</button>
        </Form>
      </Formik>
    </div>
  );
}

export default Registration;
