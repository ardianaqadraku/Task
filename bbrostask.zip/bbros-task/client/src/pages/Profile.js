import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import * as Yup from "yup";
import { useFormik } from "formik";
import axios from "axios";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
// import Typography from "@mui/material/Typography";

function Profile() {
  let { id } = useParams();
  const [user, setUser] = useState({
    firstname: "",
    lastname: "",
    bday: "",
    username: "",
  });
  const [username, setUsername] = useState("");
  // const [listOfPosts, setListOfPosts] = useState([]);

  const validationSchema = Yup.object().shape({
    firstname: Yup.string(),
    lastname: Yup.string(),
    bday: Yup.date(),
    username: Yup.string(),
    password: Yup.string(),
  });

  const onSubmit = (data) => {
    console.log("sukeses", data);
    axios
      .put(
        `http://localhost:3001/auth/basicinfo/${id}`,
        {
          id,
          firstname: data.firstname,
          lastname: data.lastname,
          username: data.username,
        },
        {
          headers: { accessToken: localStorage.getItem("accessToken") },
        }
      )
      .then(({ data }) => {
        setUser(data);
      });
  };

  const formik = useFormik({
    enableReinitialize: true,
    initialValues: user,
    validationSchema: validationSchema,
    onSubmit: (values) => {
      //  alert(JSON.stringify(values, null, 2));
      onSubmit(values);
    },
  });

  useEffect(() => {
    axios.get(`http://localhost:3001/auth/basicinfo/${id}`).then((response) => {
      setUsername(response.data.username);
      setUser(response.data);
    });

    // axios.get(`http://localhost:3001/posts/byuserId/${id}`).then((response) => {
    //   setListOfPosts(response.data);
    // });
  }, []);

  return (
    <div className="profilePageContainer">
      <div className="basicInfo">
        <h1>Username: {username} </h1>
      </div>
      <form onSubmit={formik.handleSubmit}>
        <TextField
          fullWidth
          id="username"
          name="username"
          label="Username"
          value={formik.values.username}
          onChange={formik.handleChange}
          error={formik.touched.username && Boolean(formik.errors.username)}
          helperText={formik.touched.username && formik.errors.username}
        />
        <TextField
          fullWidth
          id="firstname"
          name="firstname"
          label="First name"
          value={formik.values.firstname}
          onChange={formik.handleChange}
          error={formik.touched.firstname && Boolean(formik.errors.firstname)}
          helperText={formik.touched.firstname && formik.errors.firstname}
        />
        <TextField
          fullWidth
          id="lastaname"
          name="lastname"
          label="Last name"
          value={formik.values.lastname}
          onChange={formik.handleChange}
          error={formik.touched.lastname && Boolean(formik.errors.lastname)}
          helperText={formik.touched.lastname && formik.errors.lastname}
        />
        <Button color="primary" variant="contained" fullWidth type="submit">
          Submit
        </Button>
      </form>
    </div>
  );
}

export default Profile;
