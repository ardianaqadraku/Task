import React, { useState } from "react";
import { Formik, Form, Field } from "formik";
import axios from "axios";
import Button from "@mui/material/Button";
import Link from "@mui/material/Link";
import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import CssBaseline from "@mui/material/CssBaseline";
import Typography from "@mui/material/Typography";
import { createTheme, ThemeProvider } from "@mui/material/styles";

function Copyright(props) {
  return (
    <Typography
      variant="body2"
      color="text.secondary"
      align="center"
      {...props}
    >
      {"Copyright © "}
      <Link color="inherit" href="https://www.bbros.eu/">
        BBros L.L.C
      </Link>{" "}
      {new Date().getFullYear()}
      {"."}
    </Typography>
  );
}

const theme = createTheme();

function ChangePassword() {
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");

  const changePassword = () => {
    axios
      .put(
        "http://localhost:3001/auth/changepassword",
        {
          oldPassword: oldPassword,
          newPassword: newPassword,
        },
        {
          headers: {
            accessToken: localStorage.getItem("accessToken"),
          },
        }
      )
      .then((response) => {
        if (response.data.error) {
          alert(response.data.error);
        }
      });
  };

  return (
    <ThemeProvider theme={theme}>
      <Grid container component="main">
        <CssBaseline />

        <Grid
          item
          xs={12}
          sm={12}
          md={12}
          component={Paper}
          elevation={6}
          square
        >
          <Box
            sx={{
              my: 8,
              mx: 4,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
            }}
          >
            <Typography component="h1" variant="h5">
              Change Your Password
            </Typography>
            <Formik
            //   initialValues={initialValues}
            //   onSubmit={onSubmit}
            //   validationSchema={validationSchema}
            >
              <Form className="formContainer">
                <Box sx={{ mt: 1 }}>
                  <Field
                    variant="standard"
                    margin="normal"
                    required
                    label="Old Password"
                    type="password"
                    autoComplete="off"
                    autoFocus
                    className="inputi"
                    onChange={(event) => {
                      setOldPassword(event.target.value);
                    }}
                  />
                  <Field
                    variant="standard"
                    margin="normal"
                    required
                    label="New Password"
                    type="password"
                    autoComplete="off"
                    autoFocus
                    className="inputi"
                    onChange={(event) => {
                      setNewPassword(event.target.value);
                    }}
                  />

                  <Button
                    type="submit"
                    // fullWidth
                    variant="contained"
                    sx={{ mt: 3, mb: 2 }}
                    onClick={changePassword}
                  >
                    Change Password
                  </Button>
                </Box>
              </Form>
            </Formik>
          </Box>
        </Grid>
      </Grid>
      <Copyright sx={{ mt: 5 }} />
    </ThemeProvider>
  );
}

export default ChangePassword;
