const { verify } = require("jsonwebtoken");

// here we make a bunch of checks to see of user has access to do smth

const validateToken = (req, res, next) => {
    const accessToken = req.header("accessToken");

    if (!accessToken)
        return res.json({error: "You're not logged in"});

    try {
        const validToken = verify(accessToken, "importantsecretword");
        req.user = validToken;

        if(validToken) {
            return next();
        }
    } 
    catch (err) {
        return res.json({error: err});
    }
};

module.exports = { validateToken };