module.exports = (sequelize, DataTypes) => {
    // we create autmatically tables from here
        const Comments = sequelize.define("Comments", {
            commentBody: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            username: {
                type: DataTypes.STRING,
                allowNull: false,
            },
        });
    
        return Comments
    };