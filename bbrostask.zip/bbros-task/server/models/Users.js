module.exports = (sequelize, DataTypes) => {
    // we create autmatically tables from here
        const Users = sequelize.define("Users", {
            firstname: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            lastname: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            bday: {
                type: DataTypes.DATE,
                allowNull: false,
            },
            username: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            password: {
                type: DataTypes.STRING,
                allowNull: false,
            },
        });

        
    Users.associate = (models) => {
        Users.hasMany(models.Likes, {
            onDelete: "cascade",
        });
        Users.hasMany(models.Posts, {
            onDelete: "cascade",
        });
    };

  
        return Users;
    };